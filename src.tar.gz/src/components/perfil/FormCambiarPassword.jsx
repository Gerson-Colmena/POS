import React, { useState } from 'react';
import { Eye, EyeOff, ShieldCheck } from 'lucide-react';

function InputPassword({ value, onChange, placeholder }) {
    const [visible, setVisible] = useState(false);
    return (
        <div className="relative">
            <input
                type={visible ? 'text' : 'password'}
                value={value}
                onChange={e => onChange(e.target.value)}
                placeholder={placeholder}
                className="w-full px-4 py-2.5 pr-10 rounded-xl border border-gray-200 dark:border-gray-600 bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
            <button
                type="button"
                onClick={() => setVisible(!visible)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
            >
                {visible ? <EyeOff size={15} /> : <Eye size={15} />}
            </button>
        </div>
    );
}

export default function FormCambiarPassword() {
    const [actual, setActual]         = useState('');
    const [nueva, setNueva]           = useState('');
    const [confirmar, setConfirmar]   = useState('');
    const [exito, setExito]           = useState(false);

    const handleGuardar = () => {
        if (!actual || !nueva || !confirmar) {
            alert('Completa todos los campos'); return;
        }
        if (nueva !== confirmar) {
            alert('Las contraseñas nuevas no coinciden'); return;
        }
        if (nueva.length < 6) {
            alert('La contraseña debe tener al menos 6 caracteres'); return;
        }
        // Aquí irá la llamada a Supabase
        setExito(true);
        setActual(''); setNueva(''); setConfirmar('');
        setTimeout(() => setExito(false), 3000);
    };

    return (
        <div className="space-y-4">
            <h4 className="text-xs font-bold text-gray-400 dark:text-gray-500 uppercase tracking-wider">
                Cambiar contraseña
            </h4>

            <InputPassword value={actual}   onChange={setActual}   placeholder="Contraseña actual"   />
            <InputPassword value={nueva}    onChange={setNueva}    placeholder="Nueva contraseña"    />
            <InputPassword value={confirmar} onChange={setConfirmar} placeholder="Confirmar contraseña" />

            {/* Indicador de fortaleza */}
            {nueva.length > 0 && (
                <div>
                    <div className="flex gap-1 mb-1">
                        {[1,2,3,4].map(n => (
                            <div key={n} className={`flex-1 h-1 rounded-full transition-colors ${
                                nueva.length < 4 ? (n === 1 ? 'bg-rose-500' : 'bg-gray-200 dark:bg-gray-700') :
                                nueva.length < 6 ? (n <= 2 ? 'bg-amber-500' : 'bg-gray-200 dark:bg-gray-700') :
                                nueva.length < 10 ? (n <= 3 ? 'bg-indigo-500' : 'bg-gray-200 dark:bg-gray-700') :
                                'bg-green-500'
                            }`} />
                        ))}
                    </div>
                    <p className="text-xs text-gray-400 dark:text-gray-500">
                        {nueva.length < 4 ? '🔴 Muy corta' :
                         nueva.length < 6 ? '🟡 Débil' :
                         nueva.length < 10 ? '🔵 Buena' : '🟢 Fuerte'}
                    </p>
                </div>
            )}

            {/* Éxito */}
            {exito && (
                <div className="flex items-center gap-2 text-sm text-green-600 dark:text-green-400 bg-green-50 dark:bg-green-500/10 px-4 py-3 rounded-xl border border-green-100 dark:border-green-500/20">
                    <ShieldCheck size={16} />
                    Contraseña actualizada correctamente
                </div>
            )}

            <button
                onClick={handleGuardar}
                className="w-full flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-bold py-2.5 rounded-xl transition-all shadow-md"
            >
                <ShieldCheck size={15} />
                Actualizar contraseña
            </button>
        </div>
    );
}