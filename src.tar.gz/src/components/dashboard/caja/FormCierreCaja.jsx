import React, { useState } from 'react';
import { Lock, AlertTriangle } from 'lucide-react';

export default function FormCierreCaja({ montoInicial, ventasDelDia, onCerrar }) {
    const [montoContado, setMontoContado] = useState('');

    const montoEsperado = montoInicial + ventasDelDia;
    const diferencia = montoContado ? parseFloat(montoContado) - montoEsperado : null;
    const hayDescuadre = diferencia !== null && Math.abs(diferencia) > 0.01;

    const handleCerrar = () => {
        if (!montoContado) {
            alert('Ingresa el monto contado');
            return;
        }
        onCerrar({
            montoContado: parseFloat(montoContado),
            montoEsperado,
            diferencia,
        });
    };

    return (
        <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 border border-gray-100 dark:border-gray-700 shadow-sm">
            <h3 className="text-base font-bold text-gray-900 dark:text-white mb-1">
                Cierre de Caja
            </h3>
            <p className="text-sm text-gray-400 dark:text-gray-500 mb-5">
                Cuenta el efectivo y registra el cierre del turno.
            </p>

            {/* Resumen del día */}
            <div className="grid grid-cols-2 gap-3 mb-5">
                <div className="bg-gray-50 dark:bg-gray-900/50 rounded-xl p-3 border border-gray-100 dark:border-gray-700">
                    <p className="text-xs text-gray-400 dark:text-gray-500">Monto inicial</p>
                    <p className="text-lg font-bold text-gray-900 dark:text-white">
                        Bs. {montoInicial.toFixed(2)}
                    </p>
                </div>
                <div className="bg-gray-50 dark:bg-gray-900/50 rounded-xl p-3 border border-gray-100 dark:border-gray-700">
                    <p className="text-xs text-gray-400 dark:text-gray-500">Ventas del día</p>
                    <p className="text-lg font-bold text-green-600 dark:text-green-400">
                        + Bs. {ventasDelDia.toFixed(2)}
                    </p>
                </div>
                <div className="col-span-2 bg-indigo-50 dark:bg-indigo-500/10 rounded-xl p-3 border border-indigo-100 dark:border-indigo-500/20">
                    <p className="text-xs text-indigo-400 dark:text-indigo-500">Monto esperado en caja</p>
                    <p className="text-xl font-extrabold text-indigo-700 dark:text-indigo-400">
                        Bs. {montoEsperado.toFixed(2)}
                    </p>
                </div>
            </div>

            {/* Input monto contado */}
            <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">
                    Monto contado físicamente (Bs.)
                </label>
                <input
                    type="number"
                    value={montoContado}
                    onChange={(e) => setMontoContado(e.target.value)}
                    placeholder="Ej: 1240.00"
                    min="0"
                    className="w-full px-4 py-2.5 rounded-xl border border-gray-200 dark:border-gray-600 bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
            </div>

            {/* Alerta de descuadre */}
            {hayDescuadre && (
                <div className={`flex items-center gap-2 text-sm font-medium px-4 py-3 rounded-xl mb-4 ${
                    diferencia < 0
                    ? 'bg-rose-50 dark:bg-rose-500/10 text-rose-600 dark:text-rose-400 border border-rose-100 dark:border-rose-500/20'
                    : 'bg-amber-50 dark:bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-100 dark:border-amber-500/20'
                }`}>
                    <AlertTriangle size={16} />
                    {diferencia < 0
                        ? `Faltante de Bs. ${Math.abs(diferencia).toFixed(2)}`
                        : `Sobrante de Bs. ${diferencia.toFixed(2)}`
                    }
                </div>
            )}

            <button
                onClick={handleCerrar}
                className="w-full flex items-center justify-center gap-2 bg-rose-600 hover:bg-rose-700 text-white font-bold py-3 rounded-xl transition-all active:scale-[0.98] shadow-md"
            >
                <Lock size={18} />
                Cerrar Caja
            </button>
        </div>
    );
}