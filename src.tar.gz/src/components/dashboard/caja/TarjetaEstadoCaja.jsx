import React from 'react';
import { Unlock, Lock, Clock, DollarSign } from 'lucide-react';

export default function TarjetaEstadoCaja({ estaAbierta, horaApertura, montoInicial }) {
    return (
        <div className={`rounded-2xl p-6 border ${
            estaAbierta
            ? 'bg-green-50 dark:bg-green-500/10 border-green-200 dark:border-green-500/20'
            : 'bg-gray-50 dark:bg-gray-800 border-gray-200 dark:border-gray-700'
        }`}>
            <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                    <div className={`p-3 rounded-xl ${
                        estaAbierta
                        ? 'bg-green-100 dark:bg-green-500/20 text-green-600 dark:text-green-400'
                        : 'bg-gray-200 dark:bg-gray-700 text-gray-500 dark:text-gray-400'
                    }`}>
                        {estaAbierta ? <Unlock size={24} /> : <Lock size={24} />}
                    </div>
                    <div>
                        <h3 className="text-lg font-bold text-gray-900 dark:text-white">
                            Caja {estaAbierta ? 'Abierta' : 'Cerrada'}
                        </h3>
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                            {estaAbierta ? `Turno activo desde las ${horaApertura}` : 'Sin turno activo'}
                        </p>
                    </div>
                </div>

                {estaAbierta && (
                    <div className="flex gap-6 text-right">
                        <div>
                            <div className="flex items-center gap-1 text-xs text-gray-400 dark:text-gray-500 justify-end">
                                <Clock size={12} /> Apertura
                            </div>
                            <p className="text-sm font-semibold text-gray-700 dark:text-gray-300">
                                {horaApertura}
                            </p>
                        </div>
                        <div>
                            <div className="flex items-center gap-1 text-xs text-gray-400 dark:text-gray-500 justify-end">
                                <DollarSign size={12} /> Monto inicial
                            </div>
                            <p className="text-sm font-semibold text-gray-700 dark:text-gray-300">
                                Bs. {montoInicial?.toFixed(2)}
                            </p>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
}