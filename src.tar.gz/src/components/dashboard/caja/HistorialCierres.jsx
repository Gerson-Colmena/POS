import React from 'react';
import { CheckCircle, AlertCircle } from 'lucide-react';

// Datos simulados — luego vendrán de Supabase
const cierresSimulados = [
    { id: 1, fecha: '20/03/2025', cajero: 'Gerson C.', apertura: 500, ventas: 1240, contado: 1740, diferencia: 0 },
    { id: 2, fecha: '19/03/2025', cajero: 'María L.', apertura: 500, ventas: 980,  contado: 1470, diferencia: -10 },
    { id: 3, fecha: '18/03/2025', cajero: 'Gerson C.', apertura: 500, ventas: 1540, contado: 2045, diferencia: 5 },
];

export default function HistorialCierres() {
    return (
        <div className="bg-white dark:bg-gray-800 rounded-2xl border border-gray-100 dark:border-gray-700 shadow-sm overflow-hidden">
            <div className="p-5 border-b border-gray-100 dark:border-gray-700">
                <h3 className="text-base font-bold text-gray-900 dark:text-white">
                    Historial de Cierres
                </h3>
                <p className="text-xs text-gray-400 dark:text-gray-500 mt-0.5">
                    Últimos registros de cierre de caja
                </p>
            </div>

            <div className="overflow-x-auto">
                <table className="w-full text-sm">
                    <thead>
                        <tr className="border-b border-gray-100 dark:border-gray-700 bg-gray-50 dark:bg-gray-900/50">
                            {['Fecha', 'Cajero', 'Inicial', 'Ventas', 'Contado', 'Diferencia', 'Estado'].map(h => (
                                <th key={h} className="text-left px-5 py-3 text-xs font-semibold text-gray-400 dark:text-gray-500 uppercase tracking-wider">
                                    {h}
                                </th>
                            ))}
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-50 dark:divide-gray-700/50">
                        {cierresSimulados.map((cierre) => {
                            const sinDescuadre = cierre.diferencia === 0;
                            return (
                                <tr key={cierre.id} className="hover:bg-gray-50/50 dark:hover:bg-gray-700/20 transition-colors">
                                    <td className="px-5 py-3.5 font-medium text-gray-800 dark:text-gray-200">{cierre.fecha}</td>
                                    <td className="px-5 py-3.5 text-gray-600 dark:text-gray-400">{cierre.cajero}</td>
                                    <td className="px-5 py-3.5 font-mono text-gray-600 dark:text-gray-400">Bs. {cierre.apertura.toFixed(2)}</td>
                                    <td className="px-5 py-3.5 font-mono text-green-600 dark:text-green-400">+ Bs. {cierre.ventas.toFixed(2)}</td>
                                    <td className="px-5 py-3.5 font-mono text-gray-700 dark:text-gray-300">Bs. {cierre.contado.toFixed(2)}</td>
                                    <td className="px-5 py-3.5 font-mono font-semibold">
                                        <span className={cierre.diferencia === 0 ? 'text-gray-400' : cierre.diferencia < 0 ? 'text-rose-500' : 'text-amber-500'}>
                                            {cierre.diferencia === 0 ? '—' : `${cierre.diferencia > 0 ? '+' : ''}Bs. ${cierre.diferencia.toFixed(2)}`}
                                        </span>
                                    </td>
                                    <td className="px-5 py-3.5">
                                        <span className={`inline-flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-lg ${
                                            sinDescuadre
                                            ? 'bg-green-100 dark:bg-green-500/10 text-green-700 dark:text-green-400'
                                            : 'bg-rose-100 dark:bg-rose-500/10 text-rose-700 dark:text-rose-400'
                                        }`}>
                                            {sinDescuadre ? <CheckCircle size={11} /> : <AlertCircle size={11} />}
                                            {sinDescuadre ? 'Cuadrado' : 'Descuadre'}
                                        </span>
                                    </td>
                                </tr>
                            );
                        })}
                    </tbody>
                </table>
            </div>
        </div>
    );
}