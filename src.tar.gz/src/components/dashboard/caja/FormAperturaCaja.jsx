import React, { useState } from 'react';
import { Unlock } from 'lucide-react';

export default function FormAperturaCaja({ onAbrir }) {
    const [monto, setMonto] = useState('');
    const [cajero, setCajero] = useState('');

    const handleSubmit = () => {
        if (!monto || !cajero) {
            alert('Completa todos los campos');
            return;
        }
        onAbrir({ monto: parseFloat(monto), cajero });
    };

    return (
        <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 border border-gray-100 dark:border-gray-700 shadow-sm">
            <h3 className="text-base font-bold text-gray-900 dark:text-white mb-1">
                Apertura de Caja
            </h3>
            <p className="text-sm text-gray-400 dark:text-gray-500 mb-5">
                Registra el efectivo con el que inicia el turno.
            </p>

            <div className="space-y-4">
                <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">
                        Nombre del cajero
                    </label>
                    <input
                        type="text"
                        value={cajero}
                        onChange={(e) => setCajero(e.target.value)}
                        placeholder="Ej: Gerson Colmena"
                        className="w-full px-4 py-2.5 rounded-xl border border-gray-200 dark:border-gray-600 bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                </div>
                <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">
                        Monto inicial en caja (Bs.)
                    </label>
                    <input
                        type="number"
                        value={monto}
                        onChange={(e) => setMonto(e.target.value)}
                        placeholder="Ej: 500.00"
                        min="0"
                        className="w-full px-4 py-2.5 rounded-xl border border-gray-200 dark:border-gray-600 bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                </div>

                <button
                    onClick={handleSubmit}
                    className="w-full flex items-center justify-center gap-2 bg-green-600 hover:bg-green-700 text-white font-bold py-3 rounded-xl transition-all active:scale-[0.98] shadow-md"
                >
                    <Unlock size={18} />
                    Abrir Caja
                </button>
            </div>
        </div>
    );
}